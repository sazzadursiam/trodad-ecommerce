<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\AddToCart;
use App\Models\Product;
use Illuminate\Http\Request;

class AddToCartController extends Controller
{
    public function addToCartStore(Request $request)
    {
        $model = new AddToCart();

        $model->userId = $request->userId;
        $model->userType = $request->userType;
        $model->productId = $request->productId;

        //condition
        $model->qty = $request->qty;

        $colNO = $request->selectedPackSize;
        $packSize = ${"packSize" . $colNO};
        $variantPrice = ${"variantPrice" . $colNO};
        $unitPrice = ${"unitPrice" . $colNO};

        $product = Product::where('id', $request->productId)->first();
        $P_SIZE = $product->$packSize;
        $PRICE = $product->$variantPrice;
        $UNIT_PRICE = $product->$unitPrice;



        $model->packSize = $P_SIZE;
        $model->price = $PRICE;
        $model->unitPrice = $UNIT_PRICE;
        $model->save();
    }
}
